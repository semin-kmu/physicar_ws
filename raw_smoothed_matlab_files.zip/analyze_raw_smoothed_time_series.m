function analyze_raw_smoothed_time_series()
%ANALYZE_RAW_SMOOTHED_TIME_SERIES  raw vs EMA-smoothed Object List 시간축 비교
%
%   같은 header.stamp 로 페어링되어 기록된 raw diagnostic Object List 와
%   EMA smoothing 이 끝난 최종 Object List 를
%   정지 / 약 0.7 m/s / 약 1.2 m/s 세 조건에 대해 시간축에서 비교한다.
%
%   이 분석은 absolute map 정확도 평가가 아니다. 지도상의 참값과 비교하지
%   않으며, "EMA smoothing 전후로 같은 후보의 좌표가 얼마나 움직였는가"와
%   "그 움직임이 차량 속도에 따라 어떻게 변하는가"만 본다.
%
%   입력 (읽기 전용, 절대 수정하지 않는다):
%       raw_smoothed_raw_smoothed_static_01_20260822_102758.csv
%       raw_smoothed_raw_smoothed_normal_0p7_01_20260822_102916.csv
%       raw_smoothed_raw_smoothed_mid_1p2_01_20260822_103444.csv
%
%   출력 (이 스크립트가 있는 디렉터리에 생성):
%       raw_smoothed_time_series_summary.csv
%       raw_smoothed_time_series_report.md
%       <run>_xy_raw_vs_smoothed.png
%       <run>_x_time_series.png
%       <run>_y_time_series.png
%       <run>_shift_and_speed.png
%       <run>_shift_histogram.png
%       raw_smoothed_speed_comparison.png
%       raw_smoothed_speed_vs_shift.png
%
%   이 파일은 UTF-8 로 저장되어 있고 출력 파일도 UTF-8 로 쓴다.
%   필요 버전: R2016b 이상 (implicit expansion, yyaxis, 스크립트 내 지역 함수).
%
%   MATLAB 기본 기능만 사용한다. Statistics / Curve Fitting 등 Toolbox 를
%   요구하는 함수(prctile, boxplot, knnsearch 등)는 쓰지 않고, 백분위수와
%   box-and-whisker 는 이 파일 안의 지역 함수로 직접 구현했다.
%
%   실행:
%       cd /home/physicar/physicar_logs
%       analyze_raw_smoothed_time_series

log_dir = fileparts(mfilename('fullpath'));
if isempty(log_dir)
    log_dir = '/home/physicar/physicar_logs';
end

cfg = build_config(log_dir);

fprintf('== analyze_raw_smoothed_time_series ==\n');
fprintf('log_dir            : %s\n', cfg.log_dir);
fprintf('assoc gate         : %.3f m\n', cfg.assoc_gate_m);
fprintf('track timeout      : %.3f s\n', cfg.track_timeout_s);
fprintf('line break gap     : %.3f s\n', cfg.line_break_s);

results = cell(1, numel(cfg.runs));
for k = 1:numel(cfg.runs)
    run_cfg = cfg.runs(k);
    csv_path = fullfile(cfg.log_dir, run_cfg.csv);
    fprintf('\n-- run %d/%d : %s\n', k, numel(cfg.runs), run_cfg.csv);
    data = read_run_csv(csv_path);
    S = process_run(data, run_cfg, cfg);
    print_run_console(S);
    plot_run_figures(S, cfg);
    results{k} = S;
end

plot_cross_run_figures(results, cfg);
summary_rows = build_summary_rows(results, cfg);
write_summary_csv(fullfile(cfg.log_dir, 'raw_smoothed_time_series_summary.csv'), summary_rows);
write_report(fullfile(cfg.log_dir, 'raw_smoothed_time_series_report.md'), results, summary_rows, cfg);

fprintf('\n생성 완료:\n');
fprintf('  %s\n', fullfile(cfg.log_dir, 'raw_smoothed_time_series_summary.csv'));
fprintf('  %s\n', fullfile(cfg.log_dir, 'raw_smoothed_time_series_report.md'));
fprintf('  PNG %d 개\n', 5 * numel(cfg.runs) + 2);
end


% ======================================================================
% 설정
% ======================================================================
function cfg = build_config(log_dir)
cfg.log_dir = log_dir;

% --- 연관(association) 파라미터 -------------------------------------
% assoc_gate_m: 한 프레임의 여러 후보에 임시 series_id 를 붙일 때 쓰는
%   최근접 연관 게이트. smoothed 좌표를 기준으로 직전 프레임의 트랙 위치와의
%   거리가 이 값 이하일 때만 같은 series 로 잇는다.
%   0.12 m 로 잡은 근거:
%     - 한 프레임 안에서 서로 다른 smoothed 후보 사이의 최소 간격이
%       세 로그 전체에서 0.135 m 였다. 게이트를 그보다 작게 두면
%       한 트랙의 게이트 안에 이웃 물체가 동시에 들어와 뒤바뀔 수 없다.
%     - 반대로 연속 프레임에서 계속 잡히는 같은 후보의 이동량은
%       중앙값 1~3 cm 수준이라 0.12 m 게이트로 충분히 이어진다.
%   게이트를 넘으면 연관하지 않고 새 series_id 를 발급한다. 즉 물체가
%   튀거나 새로 나타나면 같은 물체라고 우기지 않고 series 를 끊는다.
cfg.assoc_gate_m = 0.12;

% track_timeout_s: 트랙이 이 시간 동안 갱신되지 않으면 폐기한다.
%   프레임 주기가 약 0.107 s 이므로 0.5 s 는 약 4 프레임 연속 미검출까지
%   같은 series 로 인정한다는 뜻이다.
cfg.track_timeout_s = 0.50;

% line_break_s: 그래프에서 선을 끊는 기준. 같은 series 라도 표본 사이
%   시간 간격이 이 값보다 크면 NaN 을 끼워 넣어 선을 잇지 않는다.
%   (요구사항 2: raw 또는 smoothed 가 없는 구간을 선으로 연결하지 않는다)
cfg.line_break_s = 0.25;

cfg.hist_edges_cm = 0:0.5:15;   % shift 히스토그램 공통 bin (모든 조건 동일)
cfg.dpi = 150;

% --- 속도 구간 정의 --------------------------------------------------
cfg.bands(1).name = 'static';  cfg.bands(1).lo = -Inf; cfg.bands(1).hi = 0.1;
cfg.bands(1).mode = 'lt';      cfg.bands(1).text = 'speed < 0.1 m/s';
cfg.bands(2).name = 'normal';  cfg.bands(2).lo = 0.5;  cfg.bands(2).hi = 0.9;
cfg.bands(2).mode = 'range';   cfg.bands(2).text = '0.5 <= speed <= 0.9 m/s';
cfg.bands(3).name = 'mid';     cfg.bands(3).lo = 1.0;  cfg.bands(3).hi = 1.4;
cfg.bands(3).mode = 'range';   cfg.bands(3).text = '1.0 <= speed <= 1.4 m/s';

% --- 분석 대상 로그 --------------------------------------------------
cfg.runs(1).csv   = 'raw_smoothed_raw_smoothed_static_01_20260822_102758.csv';
cfg.runs(1).cond  = 'static';
cfg.runs(1).label = '정지 (static)';
cfg.runs(1).target_band = 'static';
cfg.runs(1).color = [0.20 0.40 0.80];

cfg.runs(2).csv   = 'raw_smoothed_raw_smoothed_normal_0p7_01_20260822_102916.csv';
cfg.runs(2).cond  = 'normal_0p7';
cfg.runs(2).label = '약 0.7 m/s (normal)';
cfg.runs(2).target_band = 'normal';
cfg.runs(2).color = [0.90 0.55 0.10];

cfg.runs(3).csv   = 'raw_smoothed_raw_smoothed_mid_1p2_01_20260822_103444.csv';
cfg.runs(3).cond  = 'mid_1p2';
cfg.runs(3).label = '약 1.2 m/s (mid)';
cfg.runs(3).target_band = 'mid';
cfg.runs(3).color = [0.75 0.20 0.25];
end


% ======================================================================
% CSV 읽기 (원본은 열기만 하고 절대 쓰지 않는다)
% ======================================================================
function data = read_run_csv(csv_path)
if exist(csv_path, 'file') ~= 2
    error('analyze:missingCsv', 'CSV 를 찾을 수 없습니다: %s', csv_path);
end

fid = fopen(csv_path, 'r', 'n', 'UTF-8');
if fid < 0
    error('analyze:openCsv', 'CSV 를 열 수 없습니다: %s', csv_path);
end
clean = onCleanup(@() fclose(fid)); %#ok<NASGU>

header_line = fgetl(fid);
if ~ischar(header_line)
    error('analyze:emptyCsv', 'CSV 가 비어 있습니다: %s', csv_path);
end
names = strtrim(strsplit(strtrim(header_line), ','));

% 텍스트 열과 숫자 열을 헤더 이름으로 구분한다. 순서가 바뀌어도 동작한다.
text_cols = {'run_name', 'frame_id'};
fmt_parts = cell(1, numel(names));
for k = 1:numel(names)
    if any(strcmp(names{k}, text_cols))
        fmt_parts{k} = '%q';
    else
        fmt_parts{k} = '%f';
    end
end
fmt = strjoin(fmt_parts, '');

% 결측은 이 CSV 에서 문자열 'nan' 으로 기록된다. %f 가 그대로 NaN 으로
% 읽지만, 대소문자 표기가 섞여도 안전하도록 TreatAsEmpty 를 함께 준다.
raw = textscan(fid, fmt, 'Delimiter', ',', ...
    'TreatAsEmpty', {'nan', 'NaN', 'NAN', 'NA', ''}, ...
    'EmptyValue', NaN, 'CollectOutput', false);

n_rows = numel(raw{1});
data = struct();
for k = 1:numel(names)
    field = matlab.lang.makeValidName(names{k});
    col = raw{k};
    if numel(col) < n_rows
        % 마지막 줄이 잘린 경우를 대비해 길이를 맞춘다.
        if iscell(col)
            col(end+1:n_rows, 1) = {''};
        else
            col(end+1:n_rows, 1) = NaN;
        end
    end
    data.(field) = col;
end

required = {'frame_index', 'elapsed_s', 'vehicle_speed_mps', ...
    'raw_x_m', 'raw_y_m', 'smoothed_x_m', 'smoothed_y_m', ...
    'raw_to_smoothed_m', 'matched', ...
    'raw_candidate_count', 'smoothed_candidate_count', 'matched_candidate_count'};
for k = 1:numel(required)
    if ~isfield(data, required{k})
        error('analyze:missingColumn', ...
            '필요한 열이 없습니다: %s (%s)', required{k}, csv_path);
    end
end

if isfield(data, 'run_name') && ~isempty(data.run_name)
    data.run_name_str = data.run_name{1};
else
    [~, base] = fileparts(csv_path);
    data.run_name_str = base;
end
data.n_rows = n_rows;
data.csv_path = csv_path;
end


% ======================================================================
% 한 조건 처리
% ======================================================================
function S = process_run(data, run_cfg, cfg)
S.csv_path   = data.csv_path;
S.csv_name   = get_file_name(data.csv_path);
S.run_name   = data.run_name_str;
S.cond       = run_cfg.cond;
S.label      = run_cfg.label;
S.color      = run_cfg.color;
S.target_band = run_cfg.target_band;
S.n_rows     = data.n_rows;

t      = data.elapsed_s(:);
frame  = data.frame_index(:);
speed  = data.vehicle_speed_mps(:);
rx     = data.raw_x_m(:);
ry     = data.raw_y_m(:);
sx     = data.smoothed_x_m(:);
sy     = data.smoothed_y_m(:);
d_csv  = data.raw_to_smoothed_m(:);

has_raw = isfinite(rx) & isfinite(ry);
has_sm  = isfinite(sx) & isfinite(sy);
paired  = has_raw & has_sm;

% shift 를 좌표에서 다시 계산하고 CSV 의 raw_to_smoothed_m 과 대조한다.
% (수집기와 분석기가 같은 값을 보고 있는지 확인하는 정합성 점검)
shift_cm = NaN(size(t));
shift_cm(paired) = hypot(sx(paired) - rx(paired), sy(paired) - ry(paired)) * 100;
csv_cm = d_csv * 100;
both = paired & isfinite(csv_cm);
if any(both)
    S.shift_recompute_max_diff_cm = max(abs(shift_cm(both) - csv_cm(both)));
else
    S.shift_recompute_max_diff_cm = NaN;
end

S.t = t;
S.frame = frame;
S.speed = speed;
S.raw_x = rx;  S.raw_y = ry;
S.sm_x  = sx;  S.sm_y  = sy;
S.has_raw = has_raw;
S.has_sm  = has_sm;
S.paired  = paired;
S.shift_cm = shift_cm;

% --- 임시 series_id 부여 -------------------------------------------
% smoothed 좌표 기준 최근접 연관. 게이트를 넘거나 트랙이 만료되면
% 새 series_id 를 발급해 구간을 끊는다.
S.series_id = assign_series(frame, t, sx, sy, cfg.assoc_gate_m, cfg.track_timeout_s);
S.n_series = max([0; S.series_id]);

% smoothed 가 없는 raw-only 후보는 series 에 넣지 않는다(series_id = 0).
S.raw_only = has_raw & ~has_sm;
S.smoothed_only = has_sm & ~has_raw;
S.empty_rows = ~has_raw & ~has_sm;

% --- 프레임 단위 축약 ------------------------------------------------
% 기본 unique 는 오름차순 정렬 + 첫 등장 인덱스를 준다 (legacy 플래그 사용 안 함).
[uf, ia] = unique(frame);
n_frames = numel(uf);

F.frame = uf;
F.t = t(ia);
F.speed = speed(ia);
F.n_raw = zeros(n_frames, 1);
F.n_sm = zeros(n_frames, 1);
F.n_paired = zeros(n_frames, 1);
F.shift_mean_cm = NaN(n_frames, 1);
F.shift_max_cm = NaN(n_frames, 1);

% frame_index 는 오름차순으로 기록되므로 구간 경계를 한 번만 계산해 쓴다.
% 가정이 깨지면(프레임이 섞여 기록되면) 아래 검사에서 멈춘다.
edges = [find([true; diff(frame) ~= 0]); numel(frame) + 1];
if numel(edges) - 1 ~= n_frames || ~isequal(frame(edges(1:end-1)), uf)
    error('analyze:frameOrder', ...
        'frame_index 가 프레임 단위로 연속 정렬되어 있지 않습니다: %s', data.csv_path);
end
for k = 1:n_frames
    idx = edges(k):(edges(k+1) - 1);
    F.n_raw(k) = sum(has_raw(idx));
    F.n_sm(k) = sum(has_sm(idx));
    F.n_paired(k) = sum(paired(idx));
    v = shift_cm(idx);
    v = v(isfinite(v));
    if ~isempty(v)
        F.shift_mean_cm(k) = mean(v);
        F.shift_max_cm(k) = max(v);
    end
end
S.F = F;
S.n_frames = n_frames;
S.n_paired_frames = sum(F.n_paired > 0);
S.n_unpaired_frames = n_frames - S.n_paired_frames;
S.n_raw_candidates = sum(has_raw);
S.n_sm_candidates = sum(has_sm);
S.n_paired_candidates = sum(paired);
S.n_raw_only = sum(S.raw_only);
S.n_smoothed_only = sum(S.smoothed_only);
S.n_empty_rows = sum(S.empty_rows);

% 수집기가 기록한 후보 수와 우리가 센 값이 같은지 확인
S.count_check_raw = sum(F.n_raw) - sum_frame_first(data.raw_candidate_count(:), edges);
S.count_check_sm = sum(F.n_sm) - sum_frame_first(data.smoothed_candidate_count(:), edges);

% --- 통계 (전체 + 속도 구간별) ---------------------------------------
S.stats_all = subset_stats(S, true(n_frames, 1), 'all', 'all frames');
S.stats_bands = struct([]);
for b = 1:numel(cfg.bands)
    band = cfg.bands(b);
    mask = band_mask(F.speed, band);
    st = subset_stats(S, mask, band.name, band.text);
    st.is_target = strcmp(band.name, run_cfg.target_band);
    if isempty(S.stats_bands)
        S.stats_bands = st;
    else
        S.stats_bands(end+1) = st; %#ok<AGROW>
    end
end
end


function total = sum_frame_first(col, edges)
% 프레임별 첫 행에 기록된 후보 수의 합 (수집기 기록값)
total = 0;
for k = 1:(numel(edges) - 1)
    v = col(edges(k));
    if isfinite(v)
        total = total + v;
    end
end
end


function mask = band_mask(speed, band)
switch band.mode
    case 'lt'
        mask = isfinite(speed) & speed < band.hi;
    otherwise
        mask = isfinite(speed) & speed >= band.lo & speed <= band.hi;
end
end


function st = subset_stats(S, frame_mask, name, text)
%SUBSET_STATS  프레임 마스크에 해당하는 구간의 shift / 속도 통계
st.name = name;
st.text = text;
st.n_frames = sum(frame_mask);

sel_frames = S.F.frame(frame_mask);
row_mask = ismember(S.frame, sel_frames);

st.n_paired_frames = sum(frame_mask & S.F.n_paired > 0);
st.n_unpaired_frames = st.n_frames - st.n_paired_frames;
st.n_raw_candidates = sum(S.has_raw & row_mask);
st.n_sm_candidates = sum(S.has_sm & row_mask);
st.n_paired_candidates = sum(S.paired & row_mask);
st.n_raw_only = sum(S.raw_only & row_mask);

v = S.shift_cm(row_mask);
v = v(isfinite(v));
st.n_shift = numel(v);
st.shift_mean = safe_mean(v);
st.shift_median = pct(v, 50);
st.shift_p95 = pct(v, 95);
st.shift_p99 = pct(v, 99);
st.shift_max = safe_max(v);
st.shift_std = safe_std(v);

sp = S.F.speed(frame_mask);
sp = sp(isfinite(sp));
st.speed_min = safe_min(sp);
st.speed_median = pct(sp, 50);
st.speed_mean = safe_mean(sp);
st.speed_p95 = pct(sp, 95);
st.speed_max = safe_max(sp);
st.is_target = false;
end


% ======================================================================
% smoothed 좌표 기준 최근접 연관으로 임시 series_id 부여
% ======================================================================
function series_id = assign_series(frame, t, sx, sy, gate_m, timeout_s)
%ASSIGN_SERIES  프레임별 smoothed 후보를 직전 트랙과 최근접 연관한다.
%
%   - 거리 계산은 smoothed 좌표만 사용한다(요구사항 3).
%   - 같은 프레임 안에서는 "가장 가까운 쌍부터" 1:1 로 확정하는
%     greedy closest-first 방식이라 실행 순서에 의존하지 않는다.
%   - 게이트(gate_m)를 넘으면 연관하지 않고 새 series 를 만든다.
%   - 마지막 갱신 이후 timeout_s 가 지난 트랙은 폐기한다. 그래서
%     오래 끊겼다가 다시 나타난 후보는 이전 series 와 이어지지 않는다.
%   - smoothed 가 없는 행(raw-only)은 series_id = 0 으로 남긴다.

n = numel(sx);
series_id = zeros(n, 1);
valid = isfinite(sx) & isfinite(sy);
if ~any(valid)
    return;
end

edges = [find([true; diff(frame) ~= 0]); n + 1];
n_frames = numel(edges) - 1;

track_x = [];
track_y = [];
track_t = [];
track_id = [];
next_id = 1;

for k = 1:n_frames
    idx = (edges(k):(edges(k+1) - 1))';
    idx = idx(valid(idx));
    if isempty(idx)
        continue;
    end
    t_frame = t(idx(1));

    % 만료된 트랙 폐기
    if ~isempty(track_t)
        alive = (t_frame - track_t) <= timeout_s;
        track_x = track_x(alive);
        track_y = track_y(alive);
        track_t = track_t(alive);
        track_id = track_id(alive);
    end

    n_obs = numel(idx);
    assigned = zeros(n_obs, 1);

    if ~isempty(track_x)
        D = hypot(sx(idx) - track_x(:)', sy(idx) - track_y(:)');
        D(D > gate_m) = Inf;
        used_track = false(1, numel(track_x));
        while true
            [col_min, row_of_col] = min(D, [], 1);
            [best, col] = min(col_min);
            if ~isfinite(best)
                break;
            end
            row = row_of_col(col);
            assigned(row) = track_id(col);
            used_track(col) = true;
            D(row, :) = Inf;
            D(:, col) = Inf;
        end
        % 연관된 트랙 위치 갱신
        for j = 1:numel(track_id)
            if used_track(j)
                r = idx(assigned == track_id(j));
                track_x(j) = sx(r(1));
                track_y(j) = sy(r(1));
                track_t(j) = t_frame;
            end
        end
    end

    % 연관 실패한 후보는 새 series 로 발급
    new_rows = find(assigned == 0);
    for j = 1:numel(new_rows)
        r = idx(new_rows(j));
        assigned(new_rows(j)) = next_id;
        track_x(end+1, 1) = sx(r); %#ok<AGROW>
        track_y(end+1, 1) = sy(r); %#ok<AGROW>
        track_t(end+1, 1) = t_frame; %#ok<AGROW>
        track_id(end+1, 1) = next_id; %#ok<AGROW>
        next_id = next_id + 1;
    end

    series_id(idx) = assigned;
end
end


% ======================================================================
% 그림
% ======================================================================
function plot_run_figures(S, cfg)
prefix = fullfile(cfg.log_dir, S.run_name);
plot_xy(S, cfg, [prefix '_xy_raw_vs_smoothed.png']);
plot_axis_time(S, cfg, 'x', [prefix '_x_time_series.png']);
plot_axis_time(S, cfg, 'y', [prefix '_y_time_series.png']);
plot_shift_and_speed(S, cfg, [prefix '_shift_and_speed.png']);
plot_shift_histogram(S, cfg, [prefix '_shift_histogram.png']);
end


function plot_xy(S, cfg, out_path)
fig = new_figure(1100, 780);
ax = axes('Parent', fig);
hold(ax, 'on');

h_raw = plot(ax, S.raw_x(S.has_raw), S.raw_y(S.has_raw), '.', ...
    'Color', [0.72 0.72 0.72], 'MarkerSize', 5);

ids = series_list(S);
colors = lines(max(numel(ids), 1));
h_sm = [];
for k = 1:numel(ids)
    m = S.series_id == ids(k);
    [~, xg] = break_gaps(S.t(m), S.sm_x(m), cfg.line_break_s);
    [~, yg] = break_gaps(S.t(m), S.sm_y(m), cfg.line_break_s);
    h = plot(ax, xg, yg, '-', 'Color', colors(k, :), 'LineWidth', 1.0);
    if isempty(h_sm)
        h_sm = h;
    end
end

grid(ax, 'on');
axis(ax, 'equal');
xlabel(ax, 'map x [m]');
ylabel(ax, 'map y [m]');
title(ax, sprintf('%s : raw vs smoothed 후보 XY (series %d 개, gate %.2f m)', ...
    S.label, numel(ids), cfg.assoc_gate_m));
if ~isempty(h_sm)
    legend(ax, [h_raw, h_sm], {'raw 후보', 'smoothed (series 별 색)'}, 'Location', 'best');
else
    legend(ax, h_raw, {'raw 후보'}, 'Location', 'best');
end
save_figure(fig, out_path, cfg);
end


function plot_axis_time(S, cfg, which_axis, out_path)
if strcmp(which_axis, 'x')
    raw_v = S.raw_x;  sm_v = S.sm_x;  axis_name = 'x';
else
    raw_v = S.raw_y;  sm_v = S.sm_y;  axis_name = 'y';
end

fig = new_figure(1200, 760);
ax = axes('Parent', fig);
hold(ax, 'on');

ids = series_list(S);
colors = lines(max(numel(ids), 1));
h_raw = [];
h_sm = [];
for k = 1:numel(ids)
    m = S.series_id == ids(k);
    tk = S.t(m);
    % raw 값이 없는 표본은 NaN 이라 자동으로 선이 끊긴다.
    [tg, rg] = break_gaps(tk, raw_v(m), cfg.line_break_s);
    [~, sg] = break_gaps(tk, sm_v(m), cfg.line_break_s);
    hr = plot(ax, tg, rg, '-', 'Color', [colors(k, :) * 0.45 + 0.55], 'LineWidth', 0.8);
    hs = plot(ax, tg, sg, '-', 'Color', colors(k, :), 'LineWidth', 1.4);
    if isempty(h_raw)
        h_raw = hr;
        h_sm = hs;
    end
end

grid(ax, 'on');
xlabel(ax, 'elapsed [s]');
ylabel(ax, sprintf('map %s [m]', axis_name));
title(ax, sprintf('%s : 시간에 따른 raw_%s vs smoothed_%s (series %d 개)', ...
    S.label, axis_name, axis_name, numel(ids)));
if ~isempty(h_raw)
    legend(ax, [h_raw, h_sm], ...
        {sprintf('raw %s (연한 색)', axis_name), sprintf('smoothed %s (진한 색)', axis_name)}, ...
        'Location', 'best');
end
save_figure(fig, out_path, cfg);
end


function plot_shift_and_speed(S, cfg, out_path)
fig = new_figure(1200, 720);
ax = axes('Parent', fig);

ok = isfinite(S.shift_cm);
if ~any(ok)
    fprintf('   [건너뜀] paired 후보가 없어 shift/속도 그림을 그리지 않습니다: %s\n', S.cond);
    close(fig);
    return;
end
yyaxis(ax, 'left');
hold(ax, 'on');
h_pts = plot(ax, S.t(ok), S.shift_cm(ok), '.', ...
    'Color', [0.55 0.65 0.85], 'MarkerSize', 5);
[tg, mg] = break_gaps(S.F.t, S.F.shift_mean_cm, cfg.line_break_s);
h_mean = plot(ax, tg, mg, '-', 'Color', [0.10 0.25 0.60], 'LineWidth', 1.3);
ylabel(ax, 'raw \rightarrow smoothed 거리 변화량 [cm]');
ylim(ax, [0, max([1, ceil(max(S.shift_cm(ok)) * 1.05)])]);

yyaxis(ax, 'right');
[tsg, spg] = break_gaps(S.F.t, S.F.speed, cfg.line_break_s);
h_speed = plot(ax, tsg, spg, '-', 'Color', [0.75 0.20 0.25], 'LineWidth', 1.3);
ylabel(ax, '차량 속도 [m/s]');

grid(ax, 'on');
xlabel(ax, 'elapsed [s]');
title(ax, sprintf('%s : shift [cm] 와 속도 [m/s] 시간축 비교', S.label));
legend(ax, [h_pts, h_mean, h_speed], ...
    {'후보별 shift', '프레임 평균 shift', '차량 속도'}, 'Location', 'best');
save_figure(fig, out_path, cfg);
end


function plot_shift_histogram(S, cfg, out_path)
v = S.shift_cm(isfinite(S.shift_cm));
edges = cfg.hist_edges_cm;
counts = histcounts(v, [edges, Inf]);
centers = [edges(1:end-1) + diff(edges) / 2, edges(end) + (edges(2) - edges(1)) / 2];

fig = new_figure(1000, 680);
ax = axes('Parent', fig);
bar(ax, centers, counts, 1.0, 'FaceColor', S.color, 'EdgeColor', 'none');
grid(ax, 'on');
xlabel(ax, 'raw \rightarrow smoothed 거리 변화량 [cm] (마지막 bin 은 초과분)');
ylabel(ax, '후보 수');
st = S.stats_all;
title(ax, sprintf('%s : shift 분포 (n=%d, mean %.2f, p95 %.2f, p99 %.2f, max %.2f cm)', ...
    S.label, st.n_shift, st.shift_mean, st.shift_p95, st.shift_p99, st.shift_max));
save_figure(fig, out_path, cfg);
end


function plot_cross_run_figures(results, cfg)
% --- 조건별 shift 분포 비교 (직접 그린 box-and-whisker + 동일 bin 히스토그램)
fig = new_figure(1300, 700);

ax1 = subplot(1, 2, 1, 'Parent', fig);
hold(ax1, 'on');
labels = cell(1, numel(results));
for k = 1:numel(results)
    S = results{k};
    v = S.shift_cm(isfinite(S.shift_cm));
    draw_box(ax1, k, v, 0.5, S.color);
    labels{k} = S.cond;
end
set(ax1, 'XTick', 1:numel(results), 'XTickLabel', labels);
xlim(ax1, [0.4, numel(results) + 0.6]);
grid(ax1, 'on');
ylabel(ax1, 'shift [cm]');
title(ax1, '조건별 shift 분포 (box: Q1/중앙/Q3, whisker: 1.5 IQR)');

ax2 = subplot(1, 2, 2, 'Parent', fig);
hold(ax2, 'on');
edges = cfg.hist_edges_cm;
centers = edges(1:end-1) + diff(edges) / 2;
h = zeros(1, numel(results));
for k = 1:numel(results)
    S = results{k};
    v = S.shift_cm(isfinite(S.shift_cm));
    counts = histcounts(v, edges);
    frac = counts / max(sum(counts), 1);
    h(k) = stairs(ax2, [centers, edges(end)], [frac, frac(end)], '-', ...
        'Color', S.color, 'LineWidth', 1.4);
end
grid(ax2, 'on');
xlabel(ax2, 'shift [cm] (동일 bin 0.5 cm)');
ylabel(ax2, '비율');
title(ax2, '조건별 shift 히스토그램 (정규화)');
legend(ax2, h, labels, 'Location', 'best');
save_figure(fig, fullfile(cfg.log_dir, 'raw_smoothed_speed_comparison.png'), cfg);

% --- 속도 vs shift 산점도 -------------------------------------------
fig = new_figure(1150, 720);
ax = axes('Parent', fig);
hold(ax, 'on');
h = zeros(1, numel(results));
for k = 1:numel(results)
    S = results{k};
    ok = isfinite(S.shift_cm) & isfinite(S.speed);
    h(k) = plot(ax, S.speed(ok), S.shift_cm(ok), '.', ...
        'Color', S.color, 'MarkerSize', 5);
end
% 조건별 속도 구간 경계 표시
yl = get(ax, 'YLim');
for b = 1:numel(cfg.bands)
    band = cfg.bands(b);
    if strcmp(band.mode, 'lt')
        xv = band.hi;
    else
        xv = [band.lo, band.hi];
    end
    for j = 1:numel(xv)
        plot(ax, [xv(j) xv(j)], yl, ':', 'Color', [0.6 0.6 0.6]);
    end
end
ylim(ax, yl);
grid(ax, 'on');
xlabel(ax, '차량 속도 [m/s]');
ylabel(ax, 'raw \rightarrow smoothed 거리 변화량 [cm]');
title(ax, '속도 대비 shift (조건별 색, 점선은 목표 구간 경계)');
legend(ax, h, cellfun(@(S) S.cond, results, 'UniformOutput', false), 'Location', 'best');
save_figure(fig, fullfile(cfg.log_dir, 'raw_smoothed_speed_vs_shift.png'), cfg);
end


function draw_box(ax, xpos, v, width, color)
%DRAW_BOX  Toolbox 없이 그리는 box-and-whisker
v = v(isfinite(v));
if isempty(v)
    return;
end
q1 = pct(v, 25);
q2 = pct(v, 50);
q3 = pct(v, 75);
iqr_v = q3 - q1;
lo_fence = q1 - 1.5 * iqr_v;
hi_fence = q3 + 1.5 * iqr_v;
w_lo = min(v(v >= lo_fence));
w_hi = max(v(v <= hi_fence));
out = v(v < lo_fence | v > hi_fence);

hw = width / 2;
patch('Parent', ax, ...
    'XData', [xpos - hw, xpos + hw, xpos + hw, xpos - hw], ...
    'YData', [q1, q1, q3, q3], ...
    'FaceColor', color, 'FaceAlpha', 0.25, 'EdgeColor', color, 'LineWidth', 1.2);
plot(ax, [xpos - hw, xpos + hw], [q2, q2], '-', 'Color', color, 'LineWidth', 2.0);
plot(ax, [xpos, xpos], [q3, w_hi], '-', 'Color', color, 'LineWidth', 1.0);
plot(ax, [xpos, xpos], [w_lo, q1], '-', 'Color', color, 'LineWidth', 1.0);
plot(ax, [xpos - hw/2, xpos + hw/2], [w_hi, w_hi], '-', 'Color', color, 'LineWidth', 1.0);
plot(ax, [xpos - hw/2, xpos + hw/2], [w_lo, w_lo], '-', 'Color', color, 'LineWidth', 1.0);
if ~isempty(out)
    plot(ax, repmat(xpos, numel(out), 1), out, 'o', ...
        'MarkerSize', 3, 'MarkerEdgeColor', color * 0.7 + 0.3);
end
end


function ids = series_list(S)
ids = unique(S.series_id(S.series_id > 0));
end


function [t2, v2] = break_gaps(t, v, max_gap_s)
%BREAK_GAPS  표본 간 시간 간격이 max_gap_s 보다 크면 NaN 을 끼워 선을 끊는다.
t = t(:);
v = v(:);
if numel(t) < 2
    t2 = t;
    v2 = v;
    return;
end
gaps = find(diff(t) > max_gap_s);
if isempty(gaps)
    t2 = t;
    v2 = v;
    return;
end
t2 = [];
v2 = [];
prev = 1;
for k = 1:numel(gaps)
    p = gaps(k);
    t2 = [t2; t(prev:p); NaN]; %#ok<AGROW>
    v2 = [v2; v(prev:p); NaN]; %#ok<AGROW>
    prev = p + 1;
end
t2 = [t2; t(prev:end)];
v2 = [v2; v(prev:end)];
end


function fig = new_figure(w, h)
fig = figure('Visible', 'off', 'Color', 'w', ...
    'Position', [100, 100, w, h], 'PaperPositionMode', 'auto');
end


function save_figure(fig, out_path, cfg)
print(fig, out_path, '-dpng', sprintf('-r%d', cfg.dpi));
close(fig);
fprintf('   PNG : %s\n', get_file_name(out_path));
end


% ======================================================================
% 요약 CSV / 리포트
% ======================================================================
function rows = build_summary_rows(results, cfg)
rows = {};
for k = 1:numel(results)
    S = results{k};
    rows{end+1} = make_row(S, S.stats_all, cfg, false); %#ok<AGROW>
    for b = 1:numel(S.stats_bands)
        st = S.stats_bands(b);
        rows{end+1} = make_row(S, st, cfg, st.is_target); %#ok<AGROW>
    end
end
end


function r = make_row(S, st, cfg, is_target)
r.run_name = S.run_name;
r.condition = S.cond;
r.csv_file = S.csv_name;
r.subset = st.name;
r.subset_rule = st.text;
r.is_target_band = double(is_target);
r.total_frames = st.n_frames;
r.paired_frames = st.n_paired_frames;
r.unpaired_frames = st.n_unpaired_frames;
r.raw_candidates = st.n_raw_candidates;
r.final_candidates = st.n_sm_candidates;
r.paired_candidates = st.n_paired_candidates;
r.raw_only_candidates = st.n_raw_only;
r.shift_n = st.n_shift;
r.shift_mean_cm = st.shift_mean;
r.shift_median_cm = st.shift_median;
r.shift_p95_cm = st.shift_p95;
r.shift_p99_cm = st.shift_p99;
r.shift_max_cm = st.shift_max;
r.shift_std_cm = st.shift_std;
r.speed_min_mps = st.speed_min;
r.speed_median_mps = st.speed_median;
r.speed_mean_mps = st.speed_mean;
r.speed_p95_mps = st.speed_p95;
r.speed_max_mps = st.speed_max;
r.series_count = S.n_series;
r.assoc_gate_m = cfg.assoc_gate_m;
r.track_timeout_s = cfg.track_timeout_s;
r.line_break_s = cfg.line_break_s;
end


function write_summary_csv(out_path, rows)
fid = fopen(out_path, 'w', 'n', 'UTF-8');
if fid < 0
    error('analyze:writeCsv', '요약 CSV 를 쓸 수 없습니다: %s', out_path);
end
clean = onCleanup(@() fclose(fid)); %#ok<NASGU>

names = fieldnames(rows{1});
fprintf(fid, '%s\n', strjoin(names', ','));
for k = 1:numel(rows)
    r = rows{k};
    parts = cell(1, numel(names));
    for j = 1:numel(names)
        v = r.(names{j});
        if ischar(v)
            parts{j} = v;
        elseif ~isfinite(v)
            parts{j} = 'nan';
        elseif v == fix(v) && abs(v) < 1e9 && ~any(strcmp(names{j}, ...
                {'assoc_gate_m', 'track_timeout_s', 'line_break_s'}))
            parts{j} = sprintf('%d', v);
        else
            parts{j} = sprintf('%.6g', v);
        end
    end
    fprintf(fid, '%s\n', strjoin(parts, ','));
end
fprintf('   CSV : %s\n', get_file_name(out_path));
end


function write_report(out_path, results, rows, cfg)
fid = fopen(out_path, 'w', 'n', 'UTF-8');
if fid < 0
    error('analyze:writeReport', '리포트를 쓸 수 없습니다: %s', out_path);
end
clean = onCleanup(@() fclose(fid)); %#ok<NASGU>

fprintf(fid, '# raw vs EMA-smoothed Object List 시간축 비교\n\n');
fprintf(fid, '생성: `analyze_raw_smoothed_time_series.m`\n\n');
fprintf(fid, '## 0. 이 분석이 보는 것과 보지 않는 것\n\n');
fprintf(fid, '- 같은 `header.stamp` 로 페어링된 raw diagnostic Object List 와 EMA smoothing 이 끝난 최종 Object List 를 비교한다.\n');
fprintf(fid, '- **absolute map 정확도 평가가 아니다.** 지도상의 참값(콘 실제 좌표)과 비교하지 않으므로, 여기의 shift 값이 작다고 "정확하다"는 뜻이 아니다.\n');
fprintf(fid, '- 보는 것은 두 가지뿐이다: (1) EMA smoothing 전후로 같은 후보의 좌표가 얼마나 이동했는지, (2) 그 이동량이 차량 속도에 따라 어떻게 달라지는지.\n\n');

fprintf(fid, '## 1. 입력과 처리 규칙\n\n');
fprintf(fid, '| 조건 | CSV | 데이터 행 | 프레임 |\n|---|---|---|---|\n');
for k = 1:numel(results)
    S = results{k};
    fprintf(fid, '| %s | `%s` | %d | %d |\n', S.label, S.csv_name, S.n_rows, S.n_frames);
end
fprintf(fid, '\n원본 CSV 는 읽기만 하며 수정하지 않는다.\n\n');

fprintf(fid, '### 1.1 결측 처리\n\n');
fprintf(fid, '- 이 CSV 는 결측을 문자열 `nan` 으로 기록한다. `raw_x_m/raw_y_m` 또는 `smoothed_x_m/smoothed_y_m` 중 하나라도 유한하지 않은 행은 shift 통계에서 제외한다.\n');
fprintf(fid, '- 그래프에서도 값이 없는 표본은 선으로 잇지 않는다. 결측은 NaN 으로 남겨 선이 자동으로 끊기게 하고, 표본 사이 시간 간격이 **%.2f s** 를 넘으면 NaN 을 끼워 넣어 명시적으로 구간을 끊는다(프레임 주기 약 0.107 s 기준 약 2 프레임 이상 비면 끊김).\n\n', cfg.line_break_s);

fprintf(fid, '### 1.2 임시 series_id 부여 규칙\n\n');
fprintf(fid, '한 프레임에 여러 후보가 있으므로, 시간축 그래프를 그리려면 후보를 프레임 사이로 이어야 한다. 규칙은 다음과 같다.\n\n');
fprintf(fid, '- 연관 거리는 **smoothed 좌표**로만 계산한다.\n');
fprintf(fid, '- 같은 프레임 안에서는 가장 가까운 쌍부터 확정하는 greedy closest-first 1:1 연관을 쓴다(순서 의존성 없음).\n');
fprintf(fid, '- **연관 게이트 = %.2f m.** 근거: 한 프레임 안 서로 다른 smoothed 후보의 최소 간격이 세 로그 전체에서 0.135 m 였고, 연속 프레임에서 계속 잡히는 같은 후보의 이동량은 중앙값 1~3 cm 수준이다. 게이트를 프레임 내 최소 간격보다 작게 두어 이웃 후보와 뒤바뀌지 않게 하고, 실제 이동량보다는 충분히 크게 두었다.\n', cfg.assoc_gate_m);
fprintf(fid, '- 게이트를 넘으면 연관하지 않고 **새 series_id** 를 발급한다. 즉 튀거나 새로 나타난 후보를 같은 물체로 이어 붙이지 않는다.\n');
fprintf(fid, '- **트랙 타임아웃 = %.2f s.** 마지막 갱신 후 이 시간이 지난 트랙은 폐기하므로, 오래 끊겼다가 다시 나타난 후보는 이전 series 와 이어지지 않는다(약 4 프레임 연속 미검출까지만 인정).\n', cfg.track_timeout_s);
fprintf(fid, '- smoothed 가 없는 raw-only 행은 series 에 넣지 않는다(`series_id = 0`). 후보 수 집계에는 포함되지만 궤적 선에는 쓰지 않는다.\n');
fprintf(fid, '- series_id 는 **이 분석 안에서만 쓰는 임시 식별자**다. perception 트래커의 track id 와 무관하며, 조건 사이에서도 의미가 이어지지 않는다.\n\n');

fprintf(fid, '### 1.3 통계 정의\n\n');
fprintf(fid, '- shift = `hypot(smoothed_x - raw_x, smoothed_y - raw_y) * 100` [cm]. CSV 의 `raw_to_smoothed_m` 과 재계산 값을 대조해 정합성을 확인한다.\n');
for k = 1:numel(results)
    S = results{k};
    fprintf(fid, '  - %s: 재계산 vs CSV 최대 차이 %.3g cm\n', S.cond, S.shift_recompute_max_diff_cm);
end
fprintf(fid, '- 백분위수는 Toolbox 의 `prctile` 대신 이 스크립트의 지역 함수 `pct` 로 계산한다(오름차순 정렬 후 위치 `p/100*(n-1)+1` 선형 보간).\n');
fprintf(fid, '- 속도 통계는 프레임당 1개 값(`vehicle_speed_mps`)으로 축약해 계산한다. 후보 수가 많은 프레임이 속도 통계를 왜곡하지 않게 하기 위함이다.\n\n');

fprintf(fid, '## 2. 조건별 결과 (전체 구간)\n\n');
fprintf(fid, '| 조건 | 프레임 | paired 프레임 | unpaired 프레임 | raw 후보 | final 후보 | paired 후보 | raw-only 후보 | series |\n');
fprintf(fid, '|---|---|---|---|---|---|---|---|---|\n');
for k = 1:numel(results)
    S = results{k};
    fprintf(fid, '| %s | %d | %d | %d | %d | %d | %d | %d | %d |\n', ...
        S.cond, S.n_frames, S.n_paired_frames, S.n_unpaired_frames, ...
        S.n_raw_candidates, S.n_sm_candidates, S.n_paired_candidates, ...
        S.n_raw_only, S.n_series);
end
fprintf(fid, '\n');

fprintf(fid, '| 조건 | shift 평균 | 중앙값 | P95 | P99 | 최대 [cm] |\n|---|---|---|---|---|---|\n');
for k = 1:numel(results)
    st = results{k}.stats_all;
    fprintf(fid, '| %s | %.2f | %.2f | %.2f | %.2f | %.2f |\n', ...
        results{k}.cond, st.shift_mean, st.shift_median, st.shift_p95, st.shift_p99, st.shift_max);
end
fprintf(fid, '\n');

fprintf(fid, '| 조건 | 속도 최소 | 중앙값 | 평균 | P95 | 최대 [m/s] |\n|---|---|---|---|---|---|\n');
for k = 1:numel(results)
    st = results{k}.stats_all;
    fprintf(fid, '| %s | %.3f | %.3f | %.3f | %.3f | %.3f |\n', ...
        results{k}.cond, st.speed_min, st.speed_median, st.speed_mean, st.speed_p95, st.speed_max);
end
fprintf(fid, '\n');

fprintf(fid, '## 3. 목표 주행 구간 판별\n\n');
fprintf(fid, '구간 정의: static `speed < 0.1 m/s`, normal `0.5 <= speed <= 0.9 m/s`, mid `1.0 <= speed <= 1.4 m/s`.\n\n');
fprintf(fid, '| 조건 | 구간 | 목표 여부 | 프레임 | paired 프레임 | shift n | 평균 | 중앙값 | P95 | P99 | 최대 [cm] |\n');
fprintf(fid, '|---|---|---|---|---|---|---|---|---|---|---|\n');
for k = 1:numel(results)
    S = results{k};
    for b = 1:numel(S.stats_bands)
        st = S.stats_bands(b);
        if st.is_target
            tgt = 'O';
        else
            tgt = '';
        end
        fprintf(fid, '| %s | %s | %s | %d | %d | %d | %s | %s | %s | %s | %s |\n', ...
            S.cond, st.name, tgt, st.n_frames, st.n_paired_frames, st.n_shift, ...
            fmt_num(st.shift_mean), fmt_num(st.shift_median), fmt_num(st.shift_p95), ...
            fmt_num(st.shift_p99), fmt_num(st.shift_max));
    end
end
fprintf(fid, '\n');

fprintf(fid, '### 3.1 전체 평균 속도로 조건을 판단하면 안 되는 이유\n\n');
fprintf(fid, '세 CSV 는 모두 60 s 고정 수집이고, 주행 조건 로그에는 **가감속 전후의 정지 구간이 포함**되어 있다(로그 끝의 정지 구간뿐 아니라 출발 전 정지 구간도 있다). 그래서 전체 평균 속도는 목표 속도보다 낮게 나온다.\n\n');
for k = 1:numel(results)
    S = results{k};
    st_all = S.stats_all;
    tgt = get_band_stats(S, S.target_band);
    fprintf(fid, '- **%s**: 전체 평균 %.3f m/s / 전체 중앙값 %.3f m/s 이지만, 목표 구간(`%s`)에 드는 프레임은 %d / %d (%.1f%%) 이고 그 구간 속도 평균은 %.3f m/s 다. 정지(<0.1 m/s) 구간: %s.\n', ...
        S.cond, st_all.speed_mean, st_all.speed_median, tgt.text, ...
        tgt.n_frames, S.n_frames, 100 * tgt.n_frames / max(S.n_frames, 1), tgt.speed_mean, ...
        stationary_segments_text(S, 0.1, 1.0, 0.5));
end
fprintf(fid, '\n따라서 조건 비교는 반드시 **목표 속도 구간으로 필터링한 뒤** 해야 하며, 전체 평균 속도만으로 "이 로그는 0.7 m/s 주행"이라고 판단해서는 안 된다. 정지 구간이 섞이면 shift 통계도 함께 낮게 끌려 내려간다.\n\n');

fprintf(fid, '## 4. 속도에 따른 shift 변화 판단\n\n');
write_trend_section(fid, results);

fprintf(fid, '## 5. 생성 파일\n\n');
for k = 1:numel(results)
    S = results{k};
    fprintf(fid, '- `%s_xy_raw_vs_smoothed.png` / `%s_x_time_series.png` / `%s_y_time_series.png` / `%s_shift_and_speed.png` / `%s_shift_histogram.png`\n', ...
        S.run_name, S.run_name, S.run_name, S.run_name, S.run_name);
end
fprintf(fid, '- `raw_smoothed_speed_comparison.png` (조건별 shift 분포 box + 동일 bin 히스토그램)\n');
fprintf(fid, '- `raw_smoothed_speed_vs_shift.png` (속도 대비 shift 산점도, 조건별 색)\n');
fprintf(fid, '- `raw_smoothed_time_series_summary.csv` (%d 행: 조건 x {전체, static/normal/mid 구간})\n', numel(rows));
fprintf(fid, '\n## 6. 한계\n\n');
fprintf(fid, '- shift 는 "EMA 가 점을 얼마나 옮겼는가"이지 오차가 아니다. 참값이 없으므로 이 값만으로 smoothing 이 좋아졌다/나빠졌다고 단정할 수 없다.\n');
fprintf(fid, '- raw-only 후보(최종 리스트에서 사라진 후보)는 shift 값이 정의되지 않아 통계에서 빠진다. 조건별 raw-only 후보 수를 함께 보아야 한다.\n');
fprintf(fid, '- series_id 는 후처리로 만든 임시 연관이라, 게이트(%.2f m)나 타임아웃(%.2f s)을 바꾸면 series 개수가 달라진다. 통계값(shift 분포)은 series_id 와 무관하게 계산되므로 영향받지 않는다.\n', cfg.assoc_gate_m, cfg.track_timeout_s);
fprintf('   MD  : %s\n', get_file_name(out_path));
end


function write_trend_section(fid, results)
metrics = {'shift_mean', '평균'; 'shift_median', '중앙값'; ...
    'shift_p95', 'P95'; 'shift_p99', 'P99'; 'shift_max', '최대'};
n = numel(results);
vals = NaN(size(metrics, 1), n);
names = cell(1, n);
for k = 1:n
    S = results{k};
    tgt = get_band_stats(S, S.target_band);
    names{k} = S.cond;
    for m = 1:size(metrics, 1)
        vals(m, k) = tgt.(metrics{m, 1});
    end
end

fprintf(fid, '목표 속도 구간만 필터링한 shift 통계 비교 (기준: static 구간).\n\n');
fprintf(fid, '| 지표 |');
for k = 1:n
    fprintf(fid, ' %s |', names{k});
end
fprintf(fid, ' static 대비 변화 |\n|---|');
for k = 1:n
    fprintf(fid, '---|');
end
fprintf(fid, '---|\n');
for m = 1:size(metrics, 1)
    fprintf(fid, '| %s [cm] |', metrics{m, 2});
    for k = 1:n
        fprintf(fid, ' %s |', fmt_num(vals(m, k)));
    end
    if isfinite(vals(m, 1)) && vals(m, 1) > 0 && n >= 2
        parts = cell(1, n - 1);
        for k = 2:n
            parts{k - 1} = sprintf('%+.1f%%', 100 * (vals(m, k) / vals(m, 1) - 1));
        end
        fprintf(fid, ' %s |\n', strjoin(parts, ' / '));
    else
        fprintf(fid, ' - |\n');
    end
end
fprintf(fid, '\n');

% 평균만 움직였는지, 꼬리(P95/P99)도 같이 움직였는지 판단
mean_row = vals(1, :);
p95_row = vals(3, :);
p99_row = vals(4, :);
mean_up = all(diff(mean_row) > 0);
p95_up = all(diff(p95_row) > 0);
p99_up = all(diff(p99_row) > 0);

fprintf(fid, '판단:\n\n');
if mean_up && p95_up && p99_up
    fprintf(fid, '- 평균만 나빠진 것이 아니라 **P95 / P99 꼬리도 함께 커진다**. 속도가 올라갈수록 EMA 가 옮겨야 하는 양이 전 분포에서 같이 늘어난다는 뜻이다.\n');
elseif mean_up && ~(p95_up && p99_up)
    fprintf(fid, '- 평균은 속도에 따라 커지지만 **P95/P99 꼬리는 같은 방향으로 움직이지 않는다**. 평균 변화가 소수의 큰 값이 아니라 전체 분포 이동에서 온다는 뜻이므로, 평균만 보고 꼬리까지 나빠졌다고 말하면 안 된다.\n');
elseif ~mean_up && (p95_up || p99_up)
    fprintf(fid, '- 평균은 단조 증가하지 않는데 **꼬리(P95/P99)는 커진다**. 평균만 보면 조건 차이를 놓친다. 꼬리 통계를 함께 봐야 한다.\n');
else
    fprintf(fid, '- 평균과 꼬리 모두 속도에 대해 단조 증가하지 않는다. 조건 사이 차이를 속도만으로 설명할 수 없다.\n');
end
for m = [1, 3, 4]
    if isfinite(vals(m, 1)) && vals(m, 1) > 0
        seq = cell(1, n);
        chg = cell(1, max(n - 1, 1));
        for k = 1:n
            seq{k} = fmt_num(vals(m, k));
            if k >= 2
                chg{k - 1} = sprintf('%+.1f%%', 100 * (vals(m, k) / vals(m, 1) - 1));
            end
        end
        fprintf(fid, '- %s: %s cm (static 대비 %s)\n', ...
            metrics{m, 2}, strjoin(seq, ' -> '), strjoin(chg, ', '));
    end
end
% 꼬리/평균 비율: 분포 모양이 바뀌는지
max_row = vals(5, :);
if all(isfinite(max_row)) && max(max_row) > 0 && ...
        (max(max_row) - min(max_row)) / max(max_row) < 0.05
    fprintf(fid, '- 단, **최대값은 세 조건이 %.2f ~ %.2f cm 로 사실상 같다**. 최대 하나만 보면 조건 차이를 전혀 구분할 수 없으므로 평균/중앙값/P95/P99 를 함께 봐야 한다.\n', ...
        min(max_row), max(max_row));
end
fprintf(fid, '- 꼬리/평균 비율 (P95/평균): ');
for k = 1:n
    fprintf(fid, '%s %.2f', names{k}, p95_row(k) / max(mean_row(k), eps));
    if k < n
        fprintf(fid, ' / ');
    end
end
fprintf(fid, '. 이 비율이 조건 사이에서 크게 변하지 않으면 분포 모양은 유지된 채 전체가 커진 것이고, 커지면 큰 값만 따로 악화된 것이다.\n\n');
end


function txt = stationary_segments_text(S, thresh_mps, min_dur_s, gap_s)
%STATIONARY_SEGMENTS_TEXT  속도가 thresh_mps 미만인 연속 구간을 시간 범위 문자열로
%   min_dur_s 이상 이어진 구간만 적는다. 프레임이 끊기거나 시간 간격이 gap_s 를
%   넘으면 별개 구간으로 본다.
t = S.F.t;
sp = S.F.speed;
idx = find(isfinite(sp) & sp < thresh_mps);
segs = {};
k = 1;
while k <= numel(idx)
    j = k;
    while j + 1 <= numel(idx) && idx(j + 1) == idx(j) + 1 && ...
            (t(idx(j + 1)) - t(idx(j))) <= gap_s
        j = j + 1;
    end
    if (t(idx(j)) - t(idx(k))) >= min_dur_s
        segs{end + 1} = sprintf('%.1f~%.1f s', t(idx(k)), t(idx(j))); %#ok<AGROW>
    end
    k = j + 1;
end
if isempty(segs)
    txt = sprintf('%.1f s 이상 이어진 구간 없음', min_dur_s);
else
    txt = strjoin(segs, ', ');
end
end


function st = get_band_stats(S, band_name)
st = S.stats_bands(1);
for b = 1:numel(S.stats_bands)
    if strcmp(S.stats_bands(b).name, band_name)
        st = S.stats_bands(b);
        return;
    end
end
end


function print_run_console(S)
st = S.stats_all;
fprintf('   rows=%d frames=%d paired_frames=%d unpaired_frames=%d\n', ...
    S.n_rows, S.n_frames, S.n_paired_frames, S.n_unpaired_frames);
fprintf('   raw=%d final=%d paired=%d raw_only=%d smoothed_only=%d empty=%d\n', ...
    S.n_raw_candidates, S.n_sm_candidates, S.n_paired_candidates, ...
    S.n_raw_only, S.n_smoothed_only, S.n_empty_rows);
fprintf('   series=%d  shift[cm] mean=%.2f med=%.2f p95=%.2f p99=%.2f max=%.2f\n', ...
    S.n_series, st.shift_mean, st.shift_median, st.shift_p95, st.shift_p99, st.shift_max);
fprintf('   speed[m/s] min=%.3f med=%.3f mean=%.3f p95=%.3f max=%.3f\n', ...
    st.speed_min, st.speed_median, st.speed_mean, st.speed_p95, st.speed_max);
if isfinite(S.shift_recompute_max_diff_cm)
    fprintf('   shift 재계산 vs CSV 최대 차이 = %.4g cm\n', S.shift_recompute_max_diff_cm);
end
if S.count_check_raw ~= 0 || S.count_check_sm ~= 0
    fprintf('   [경고] 후보 수 집계가 수집기 기록과 다릅니다 (raw %+d, smoothed %+d)\n', ...
        S.count_check_raw, S.count_check_sm);
end
end


% ======================================================================
% 작은 도우미 (Toolbox 대체)
% ======================================================================
function v = pct(x, p)
%PCT  Toolbox 없는 백분위수. 정렬 후 위치 p/100*(n-1)+1 선형 보간.
x = x(isfinite(x));
if isempty(x)
    v = NaN;
    return;
end
x = sort(x(:));
n = numel(x);
if n == 1
    v = x(1);
    return;
end
pos = (p / 100) * (n - 1) + 1;
lo = floor(pos);
hi = ceil(pos);
if lo == hi
    v = x(lo);
else
    v = x(lo) + (pos - lo) * (x(hi) - x(lo));
end
end


function v = safe_mean(x)
x = x(isfinite(x));
if isempty(x)
    v = NaN;
else
    v = mean(x);
end
end


function v = safe_std(x)
x = x(isfinite(x));
if numel(x) < 2
    v = NaN;
else
    v = std(x);
end
end


function v = safe_max(x)
x = x(isfinite(x));
if isempty(x)
    v = NaN;
else
    v = max(x);
end
end


function v = safe_min(x)
x = x(isfinite(x));
if isempty(x)
    v = NaN;
else
    v = min(x);
end
end


function s = fmt_num(v)
if ~isfinite(v)
    s = '-';
else
    s = sprintf('%.2f', v);
end
end


function name = get_file_name(p)
[~, base, ext] = fileparts(p);
name = [base, ext];
end
