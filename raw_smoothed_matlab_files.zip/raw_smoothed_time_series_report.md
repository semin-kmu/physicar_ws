# raw vs EMA-smoothed Object List 시간축 비교

생성: `analyze_raw_smoothed_time_series.m`

## 0. 이 분석이 보는 것과 보지 않는 것

- 같은 `header.stamp` 로 페어링된 raw diagnostic Object List 와 EMA smoothing 이 끝난 최종 Object List 를 비교한다.
- **absolute map 정확도 평가가 아니다.** 지도상의 참값(콘 실제 좌표)과 비교하지 않으므로, 여기의 shift 값이 작다고 "정확하다"는 뜻이 아니다.
- 보는 것은 두 가지뿐이다: (1) EMA smoothing 전후로 같은 후보의 좌표가 얼마나 이동했는지, (2) 그 이동량이 차량 속도에 따라 어떻게 달라지는지.

## 1. 입력과 처리 규칙

| 조건 | CSV | 데이터 행 | 프레임 |
|---|---|---|---|
| 정지 (static) | `raw_smoothed_raw_smoothed_static_01_20260822_102758.csv` | 4707 | 568 |
| 약 0.7 m/s (normal) | `raw_smoothed_raw_smoothed_normal_0p7_01_20260822_102916.csv` | 5162 | 561 |
| 약 1.2 m/s (mid) | `raw_smoothed_raw_smoothed_mid_1p2_01_20260822_103444.csv` | 5075 | 558 |

원본 CSV 는 읽기만 하며 수정하지 않는다.

### 1.1 결측 처리

- 이 CSV 는 결측을 문자열 `nan` 으로 기록한다. `raw_x_m/raw_y_m` 또는 `smoothed_x_m/smoothed_y_m` 중 하나라도 유한하지 않은 행은 shift 통계에서 제외한다.
- 그래프에서도 값이 없는 표본은 선으로 잇지 않는다. 결측은 NaN 으로 남겨 선이 자동으로 끊기게 하고, 표본 사이 시간 간격이 **0.25 s** 를 넘으면 NaN 을 끼워 넣어 명시적으로 구간을 끊는다(프레임 주기 약 0.107 s 기준 약 2 프레임 이상 비면 끊김).

### 1.2 임시 series_id 부여 규칙

한 프레임에 여러 후보가 있으므로, 시간축 그래프를 그리려면 후보를 프레임 사이로 이어야 한다. 규칙은 다음과 같다.

- 연관 거리는 **smoothed 좌표**로만 계산한다.
- 같은 프레임 안에서는 가장 가까운 쌍부터 확정하는 greedy closest-first 1:1 연관을 쓴다(순서 의존성 없음).
- **연관 게이트 = 0.12 m.** 근거: 한 프레임 안 서로 다른 smoothed 후보의 최소 간격이 세 로그 전체에서 0.135 m 였고, 연속 프레임에서 계속 잡히는 같은 후보의 이동량은 중앙값 1~3 cm 수준이다. 게이트를 프레임 내 최소 간격보다 작게 두어 이웃 후보와 뒤바뀌지 않게 하고, 실제 이동량보다는 충분히 크게 두었다.
- 게이트를 넘으면 연관하지 않고 **새 series_id** 를 발급한다. 즉 튀거나 새로 나타난 후보를 같은 물체로 이어 붙이지 않는다.
- **트랙 타임아웃 = 0.50 s.** 마지막 갱신 후 이 시간이 지난 트랙은 폐기하므로, 오래 끊겼다가 다시 나타난 후보는 이전 series 와 이어지지 않는다(약 4 프레임 연속 미검출까지만 인정).
- smoothed 가 없는 raw-only 행은 series 에 넣지 않는다(`series_id = 0`). 후보 수 집계에는 포함되지만 궤적 선에는 쓰지 않는다.
- series_id 는 **이 분석 안에서만 쓰는 임시 식별자**다. perception 트래커의 track id 와 무관하며, 조건 사이에서도 의미가 이어지지 않는다.

### 1.3 통계 정의

- shift = `hypot(smoothed_x - raw_x, smoothed_y - raw_y) * 100` [cm]. CSV 의 `raw_to_smoothed_m` 과 재계산 값을 대조해 정합성을 확인한다.
  - static: 재계산 vs CSV 최대 차이 0 cm
  - normal_0p7: 재계산 vs CSV 최대 차이 0 cm
  - mid_1p2: 재계산 vs CSV 최대 차이 0 cm
- 백분위수는 Toolbox 의 `prctile` 대신 이 스크립트의 지역 함수 `pct` 로 계산한다(오름차순 정렬 후 위치 `p/100*(n-1)+1` 선형 보간).
- 속도 통계는 프레임당 1개 값(`vehicle_speed_mps`)으로 축약해 계산한다. 후보 수가 많은 프레임이 속도 통계를 왜곡하지 않게 하기 위함이다.

## 2. 조건별 결과 (전체 구간)

| 조건 | 프레임 | paired 프레임 | unpaired 프레임 | raw 후보 | final 후보 | paired 후보 | raw-only 후보 | series |
|---|---|---|---|---|---|---|---|---|
| static | 568 | 534 | 34 | 4674 | 4268 | 4268 | 406 | 252 |
| normal_0p7 | 561 | 555 | 6 | 5162 | 4071 | 4071 | 1091 | 584 |
| mid_1p2 | 558 | 539 | 19 | 5075 | 3391 | 3391 | 1684 | 680 |

| 조건 | shift 평균 | 중앙값 | P95 | P99 | 최대 [cm] |
|---|---|---|---|---|---|
| static | 2.41 | 1.31 | 8.09 | 10.43 | 11.90 |
| normal_0p7 | 3.38 | 2.22 | 9.74 | 11.43 | 11.98 |
| mid_1p2 | 4.02 | 3.00 | 10.35 | 11.68 | 12.00 |

| 조건 | 속도 최소 | 중앙값 | 평균 | P95 | 최대 [m/s] |
|---|---|---|---|---|---|
| static | 0.000 | 0.008 | 0.009 | 0.020 | 0.028 |
| normal_0p7 | 0.001 | 0.692 | 0.494 | 0.715 | 0.732 |
| mid_1p2 | 0.001 | 1.190 | 0.934 | 1.218 | 1.239 |

## 3. 목표 주행 구간 판별

구간 정의: static `speed < 0.1 m/s`, normal `0.5 <= speed <= 0.9 m/s`, mid `1.0 <= speed <= 1.4 m/s`.

| 조건 | 구간 | 목표 여부 | 프레임 | paired 프레임 | shift n | 평균 | 중앙값 | P95 | P99 | 최대 [cm] |
|---|---|---|---|---|---|---|---|---|---|---|
| static | static | O | 568 | 534 | 4268 | 2.41 | 1.31 | 8.09 | 10.43 | 11.90 |
| static | normal |  | 0 | 0 | 0 | - | - | - | - | - |
| static | mid |  | 0 | 0 | 0 | - | - | - | - | - |
| normal_0p7 | static |  | 163 | 163 | 1312 | 2.55 | 1.43 | 8.57 | 10.94 | 11.68 |
| normal_0p7 | normal | O | 393 | 387 | 2728 | 3.74 | 2.66 | 10.11 | 11.62 | 11.98 |
| normal_0p7 | mid |  | 0 | 0 | 0 | - | - | - | - | - |
| mid_1p2 | static |  | 118 | 118 | 921 | 2.61 | 1.46 | 8.77 | 11.40 | 11.88 |
| mid_1p2 | normal |  | 2 | 1 | 2 | 5.53 | 5.53 | 8.46 | 8.72 | 8.78 |
| mid_1p2 | mid | O | 434 | 417 | 2452 | 4.53 | 3.81 | 10.75 | 11.75 | 12.00 |

### 3.1 전체 평균 속도로 조건을 판단하면 안 되는 이유

세 CSV 는 모두 60 s 고정 수집이고, 주행 조건 로그에는 **가감속 전후의 정지 구간이 포함**되어 있다(로그 끝의 정지 구간뿐 아니라 출발 전 정지 구간도 있다). 그래서 전체 평균 속도는 목표 속도보다 낮게 나온다.

- **static**: 전체 평균 0.009 m/s / 전체 중앙값 0.008 m/s 이지만, 목표 구간(`speed < 0.1 m/s`)에 드는 프레임은 568 / 568 (100.0%) 이고 그 구간 속도 평균은 0.009 m/s 다. 정지(<0.1 m/s) 구간: 0.1~59.9 s.
- **normal_0p7**: 전체 평균 0.494 m/s / 전체 중앙값 0.692 m/s 이지만, 목표 구간(`0.5 <= speed <= 0.9 m/s`)에 드는 프레임은 393 / 561 (70.1%) 이고 그 구간 속도 평균은 0.696 m/s 다. 정지(<0.1 m/s) 구간: 0.1~11.5 s, 54.4~60.0 s.
- **mid_1p2**: 전체 평균 0.934 m/s / 전체 중앙값 1.190 m/s 이지만, 목표 구간(`1.0 <= speed <= 1.4 m/s`)에 드는 프레임은 434 / 558 (77.8%) 이고 그 구간 속도 평균은 1.191 m/s 다. 정지(<0.1 m/s) 구간: 0.1~7.3 s, 55.2~60.0 s.

따라서 조건 비교는 반드시 **목표 속도 구간으로 필터링한 뒤** 해야 하며, 전체 평균 속도만으로 "이 로그는 0.7 m/s 주행"이라고 판단해서는 안 된다. 정지 구간이 섞이면 shift 통계도 함께 낮게 끌려 내려간다.

## 4. 속도에 따른 shift 변화 판단

목표 속도 구간만 필터링한 shift 통계 비교 (기준: static 구간).

| 지표 | static | normal_0p7 | mid_1p2 | static 대비 변화 |
|---|---|---|---|---|
| 평균 [cm] | 2.41 | 3.74 | 4.53 | +55.3% / +87.9% |
| 중앙값 [cm] | 1.31 | 2.66 | 3.81 | +102.9% / +191.1% |
| P95 [cm] | 8.09 | 10.11 | 10.75 | +25.0% / +32.9% |
| P99 [cm] | 10.43 | 11.62 | 11.75 | +11.3% / +12.7% |
| 최대 [cm] | 11.90 | 11.98 | 12.00 | +0.7% / +0.8% |

판단:

- 평균만 나빠진 것이 아니라 **P95 / P99 꼬리도 함께 커진다**. 속도가 올라갈수록 EMA 가 옮겨야 하는 양이 전 분포에서 같이 늘어난다는 뜻이다.
- 평균: 2.41 -> 3.74 -> 4.53 cm (static 대비 +55.3%, +87.9%)
- P95: 8.09 -> 10.11 -> 10.75 cm (static 대비 +25.0%, +32.9%)
- P99: 10.43 -> 11.62 -> 11.75 cm (static 대비 +11.3%, +12.7%)
- 단, **최대값은 세 조건이 11.90 ~ 12.00 cm 로 사실상 같다**. 최대 하나만 보면 조건 차이를 전혀 구분할 수 없으므로 평균/중앙값/P95/P99 를 함께 봐야 한다.
- 꼬리/평균 비율 (P95/평균): static 3.35 / normal_0p7 2.70 / mid_1p2 2.37. 이 비율이 조건 사이에서 크게 변하지 않으면 분포 모양은 유지된 채 전체가 커진 것이고, 커지면 큰 값만 따로 악화된 것이다.

## 5. 생성 파일

- `raw_smoothed_static_01_xy_raw_vs_smoothed.png` / `raw_smoothed_static_01_x_time_series.png` / `raw_smoothed_static_01_y_time_series.png` / `raw_smoothed_static_01_shift_and_speed.png` / `raw_smoothed_static_01_shift_histogram.png`
- `raw_smoothed_normal_0p7_01_xy_raw_vs_smoothed.png` / `raw_smoothed_normal_0p7_01_x_time_series.png` / `raw_smoothed_normal_0p7_01_y_time_series.png` / `raw_smoothed_normal_0p7_01_shift_and_speed.png` / `raw_smoothed_normal_0p7_01_shift_histogram.png`
- `raw_smoothed_mid_1p2_01_xy_raw_vs_smoothed.png` / `raw_smoothed_mid_1p2_01_x_time_series.png` / `raw_smoothed_mid_1p2_01_y_time_series.png` / `raw_smoothed_mid_1p2_01_shift_and_speed.png` / `raw_smoothed_mid_1p2_01_shift_histogram.png`
- `raw_smoothed_speed_comparison.png` (조건별 shift 분포 box + 동일 bin 히스토그램)
- `raw_smoothed_speed_vs_shift.png` (속도 대비 shift 산점도, 조건별 색)
- `raw_smoothed_time_series_summary.csv` (12 행: 조건 x {전체, static/normal/mid 구간})

## 6. 한계

- shift 는 "EMA 가 점을 얼마나 옮겼는가"이지 오차가 아니다. 참값이 없으므로 이 값만으로 smoothing 이 좋아졌다/나빠졌다고 단정할 수 없다.
- raw-only 후보(최종 리스트에서 사라진 후보)는 shift 값이 정의되지 않아 통계에서 빠진다. 조건별 raw-only 후보 수를 함께 보아야 한다.
- series_id 는 후처리로 만든 임시 연관이라, 게이트(0.12 m)나 타임아웃(0.50 s)을 바꾸면 series 개수가 달라진다. 통계값(shift 분포)은 series_id 와 무관하게 계산되므로 영향받지 않는다.
